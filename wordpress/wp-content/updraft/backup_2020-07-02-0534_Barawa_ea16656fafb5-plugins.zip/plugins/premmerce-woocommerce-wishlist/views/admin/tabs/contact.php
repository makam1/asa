<?php
    if(function_exists('premmerce_pw_fs')){
        premmerce_pw_fs()->_contact_page_render();
    }
